package com.maddox.rts;

public class BackgroundTaskCancelException extends Exception
{

    public BackgroundTaskCancelException(String s)
    {
        super(s);
    }

    private static final long serialVersionUID = 0x6f5eedd882b215b4L;
}
